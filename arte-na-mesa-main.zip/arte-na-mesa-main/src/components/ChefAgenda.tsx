import { useState } from "react";
import { Calendar } from "@/components/ui/calendar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Clock } from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

interface TimeSlot {
  time: string;
  available: boolean;
}

const timeSlots: TimeSlot[] = [
  { time: "08:00", available: true },
  { time: "09:00", available: false },
  { time: "10:00", available: true },
  { time: "11:00", available: true },
  { time: "12:00", available: false },
  { time: "13:00", available: true },
  { time: "14:00", available: true },
  { time: "15:00", available: false },
  { time: "16:00", available: true },
  { time: "17:00", available: true },
  { time: "18:00", available: true },
  { time: "19:00", available: false },
  { time: "20:00", available: true },
];

export const ChefAgenda = () => {
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date(2025, 10, 1)); // November 2025
  const [selectedTime, setSelectedTime] = useState<string | null>(null);

  return (
    <div className="grid md:grid-cols-2 gap-6">
      <Card>
        <CardHeader>
          <CardTitle>Selecione uma Data</CardTitle>
        </CardHeader>
        <CardContent className="flex justify-center">
          <Calendar
            mode="single"
            selected={selectedDate}
            onSelect={setSelectedDate}
            month={new Date(2025, 10, 1)}
            className="rounded-md border"
            disabled={(date) => {
              const today = new Date(2025, 10, 1);
              return date < today || date.getMonth() !== 10;
            }}
          />
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5" />
            {selectedDate ? format(selectedDate, "dd 'de' MMMM", { locale: ptBR }) : "Horários Disponíveis"}
          </CardTitle>
        </CardHeader>
        <CardContent>
          {selectedDate ? (
            <div className="space-y-4">
              <div className="flex gap-2 mb-4">
                <Badge variant="outline" className="bg-green-500/10 text-green-700 border-green-500/20">
                  Disponível
                </Badge>
                <Badge variant="outline" className="bg-muted text-muted-foreground">
                  Ocupado
                </Badge>
              </div>
              <div className="grid grid-cols-3 gap-2">
                {timeSlots.map((slot) => (
                  <Button
                    key={slot.time}
                    variant={selectedTime === slot.time ? "default" : "outline"}
                    disabled={!slot.available}
                    onClick={() => setSelectedTime(slot.time)}
                    className={
                      slot.available
                        ? "hover:bg-primary hover:text-primary-foreground"
                        : "opacity-50 cursor-not-allowed"
                    }
                  >
                    {slot.time}
                  </Button>
                ))}
              </div>
              {selectedTime && (
                <Button className="w-full mt-4" size="lg">
                  Solicitar Agendamento para {selectedTime}
                </Button>
              )}
            </div>
          ) : (
            <p className="text-muted-foreground text-center py-8">
              Selecione uma data no calendário para ver os horários disponíveis
            </p>
          )}
        </CardContent>
      </Card>
    </div>
  );
};
