import { Link } from "react-router-dom";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Star, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";

interface ChefCardProps {
  id: string;
  name: string;
  specialty: string;
  image: string;
  rating: number;
  reviewCount: number;
  location: string;
  available?: boolean;
}

export const ChefCard = ({
  id,
  name,
  specialty,
  image,
  rating,
  reviewCount,
  location,
  available = false,
}: ChefCardProps) => {
  return (
    <Link to={`/chef/${id}`}>
      <Card className="group overflow-hidden bg-gradient-card border-border hover:shadow-medium transition-smooth cursor-pointer">
        <div className="relative aspect-square overflow-hidden">
          <img
            src={image}
            alt={name}
            className="w-full h-full object-cover group-hover:scale-105 transition-smooth"
          />
          {available && (
            <Badge className="absolute top-3 right-3 bg-secondary text-secondary-foreground">
              Disponível hoje
            </Badge>
          )}
        </div>
        
        <div className="p-4 space-y-3">
          <div>
            <h3 className="font-semibold text-lg text-foreground group-hover:text-primary transition-smooth">
              {name}
            </h3>
            <p className="text-sm text-muted-foreground">{specialty}</p>
          </div>
          
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-1 text-accent">
              <Star className="h-4 w-4 fill-current" />
              <span className="font-medium">{rating.toFixed(1)}</span>
              <span className="text-muted-foreground">({reviewCount})</span>
            </div>
            
            <div className="flex items-center gap-1 text-muted-foreground">
              <MapPin className="h-4 w-4" />
              <span>{location}</span>
            </div>
          </div>
          
          <Button variant="outline" className="w-full" size="sm">
            Ver Perfil
          </Button>
        </div>
      </Card>
    </Link>
  );
};
