import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ChefHat, User } from "lucide-react";
import { useState } from "react";

export const Navbar = () => {
  // Simulating logged in state - in real app this would come from auth context
  const [isLoggedIn] = useState(true);
  
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-border">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2 text-2xl font-bold text-primary">
          <ChefHat className="h-8 w-8" />
          <span>Gastromania</span>
        </Link>
        
        <div className="flex items-center gap-4">
          <Link to="/dashboard">
            <Button variant="ghost">Explorar Chefs</Button>
          </Link>
          
          {isLoggedIn && (
            <>
              <Link to="/quem-somos">
                <Button variant="ghost">Quem Somos</Button>
              </Link>
              <Link to="/como-agendar">
                <Button variant="ghost">Como Agendar seu Evento</Button>
              </Link>
              <Link to="/pontos-coleta">
                <Button variant="ghost">Pontos de Coleta</Button>
              </Link>
            </>
          )}
          
          {!isLoggedIn ? (
            <>
              <Link to="/auth">
                <Button variant="outline" size="sm">
                  <User className="h-4 w-4" />
                  Entrar
                </Button>
              </Link>
              <Link to="/auth?tab=signup">
                <Button size="sm">Cadastrar</Button>
              </Link>
            </>
          ) : (
            <Button variant="outline" size="sm">
              <User className="h-4 w-4" />
              Minha Conta
            </Button>
          )}
        </div>
      </div>
    </nav>
  );
};
