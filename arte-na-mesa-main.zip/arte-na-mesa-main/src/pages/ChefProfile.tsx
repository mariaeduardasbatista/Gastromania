import { useParams } from "react-router-dom";
import { Navbar } from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Star, MapPin, Calendar, Phone, Instagram, MessageCircle } from "lucide-react";
import { ChefAgenda } from "@/components/ChefAgenda";
import { ChatTab } from "@/components/ChatTab";
import chef1 from "@/assets/chef-1.jpg";

const ChefProfile = () => {
  const { id } = useParams();

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="pt-16">
        {/* Hero Section */}
        <div className="relative h-80 bg-gradient-hero">
          <div className="absolute inset-0 bg-gradient-to-b from-transparent to-background"></div>
        </div>
        
        <div className="container mx-auto px-4 -mt-32 relative z-10">
          <div className="flex flex-col md:flex-row gap-8 items-start">
            {/* Profile Image */}
            <div className="flex-shrink-0">
              <img
                src={chef1}
                alt="Chef Ricardo Silva"
                className="w-48 h-48 rounded-lg object-cover shadow-strong border-4 border-background"
              />
            </div>
            
            {/* Profile Info */}
            <div className="flex-1 bg-card rounded-lg p-6 shadow-medium">
              <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4 mb-4">
                <div>
                  <h1 className="text-3xl font-bold text-foreground mb-2">
                    Ricardo Silva
                  </h1>
                  <p className="text-lg text-muted-foreground mb-3">
                    Culinária Brasileira Contemporânea
                  </p>
                  <div className="flex flex-wrap gap-3 text-sm">
                    <div className="flex items-center gap-1 text-accent">
                      <Star className="h-5 w-5 fill-current" />
                      <span className="font-semibold">4.9</span>
                      <span className="text-muted-foreground">(127 avaliações)</span>
                    </div>
                    <div className="flex items-center gap-1 text-muted-foreground">
                      <MapPin className="h-5 w-5" />
                      <span>São Paulo, SP</span>
                    </div>
                  </div>
                </div>
                
                <div className="flex flex-col gap-2">
                  <Button size="lg" variant="hero">
                    <Calendar className="h-5 w-5" />
                    Ver Agenda
                  </Button>
                  <Button size="lg" variant="outline">
                    <MessageCircle className="h-5 w-5" />
                    Enviar Mensagem
                  </Button>
                </div>
              </div>
              
              <div className="flex flex-wrap gap-2">
                <Badge variant="secondary">Disponível hoje</Badge>
                <Badge variant="outline">Eventos corporativos</Badge>
                <Badge variant="outline">Aulas de culinária</Badge>
              </div>
            </div>
          </div>
          
          {/* Tabs */}
          <div className="mt-8">
            <Tabs defaultValue="about" className="w-full">
              <TabsList className="w-full justify-start bg-card border-b border-border rounded-none">
                <TabsTrigger value="about">Sobre</TabsTrigger>
                <TabsTrigger value="menu">Cardápio</TabsTrigger>
                <TabsTrigger value="agenda">Agenda</TabsTrigger>
                <TabsTrigger value="reviews">Avaliações</TabsTrigger>
                <TabsTrigger value="chat">Chat</TabsTrigger>
                <TabsTrigger value="contact">Contato</TabsTrigger>
              </TabsList>
              
              <TabsContent value="about" className="mt-6">
                <Card>
                  <CardContent className="pt-6">
                    <h2 className="text-xl font-semibold mb-4">Sobre o Chef</h2>
                    <p className="text-muted-foreground leading-relaxed mb-6">
                      Com mais de 15 anos de experiência, Ricardo Silva especializou-se em dar um toque contemporâneo 
                      aos sabores tradicionais brasileiros. Formado pela Escola de Gastronomia do SENAC e com passagens 
                      por restaurantes renomados, hoje dedica-se a criar experiências gastronômicas únicas para eventos 
                      especiais e jantares particulares.
                    </p>
                    
                    <h3 className="font-semibold mb-3">Especialidades</h3>
                    <ul className="list-disc list-inside space-y-2 text-muted-foreground">
                      <li>Culinária brasileira contemporânea</li>
                      <li>Eventos corporativos e casamentos</li>
                      <li>Jantares particulares para até 20 pessoas</li>
                      <li>Aulas de culinária personalizadas</li>
                    </ul>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="menu" className="mt-6">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {[1, 2, 3, 4, 5, 6].map((item) => (
                    <Card key={item} className="overflow-hidden">
                      <div className="aspect-square bg-muted"></div>
                      <CardContent className="pt-4">
                        <h3 className="font-semibold mb-2">Prato Especial {item}</h3>
                        <p className="text-sm text-muted-foreground mb-3">
                          Descrição breve do prato com ingredientes principais
                        </p>
                        <p className="text-primary font-semibold">A partir de R$ 150</p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="agenda" className="mt-6">
                <ChefAgenda />
              </TabsContent>
              
              <TabsContent value="reviews" className="mt-6">
                <Card>
                  <CardContent className="pt-6 space-y-6">
                    {[1, 2, 3].map((review) => (
                      <div key={review} className="border-b border-border last:border-0 pb-6 last:pb-0">
                        <div className="flex items-center gap-2 mb-2">
                          <div className="flex text-accent">
                            {[...Array(5)].map((_, i) => (
                              <Star key={i} className="h-4 w-4 fill-current" />
                            ))}
                          </div>
                          <span className="text-sm text-muted-foreground">há 2 semanas</span>
                        </div>
                        <p className="font-semibold mb-2">Cliente Satisfeito</p>
                        <p className="text-muted-foreground">
                          Experiência incrível! A comida estava divina e o atendimento impecável. 
                          Recomendo fortemente para eventos especiais.
                        </p>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="chat" className="mt-6">
                <ChatTab />
              </TabsContent>

              <TabsContent value="contact" className="mt-6">
                <Card>
                  <CardContent className="pt-6">
                    <h2 className="text-xl font-semibold mb-6">Informações de Contato</h2>
                    <div className="space-y-4">
                      <div className="flex items-center gap-3">
                        <Phone className="h-5 w-5 text-primary" />
                        <span>(11) 98765-4321</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <Instagram className="h-5 w-5 text-primary" />
                        <span>@chef.ricardosilva</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <MessageCircle className="h-5 w-5 text-primary" />
                        <span>WhatsApp: (11) 98765-4321</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </main>
    </div>
  );
};

export default ChefProfile;
