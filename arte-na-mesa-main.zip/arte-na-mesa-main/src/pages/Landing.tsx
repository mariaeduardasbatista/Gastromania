import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ChefHat, Search, Calendar, Shield, Star } from "lucide-react";
import heroImage from "@/assets/hero-gastromania.jpg";

const Landing = () => {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-hero">
        <div className="absolute inset-0 z-0">
          <img
            src={heroImage}
            alt="Gastronomia premium"
            className="w-full h-full object-cover opacity-30"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-background/80 via-background/60 to-background"></div>
        </div>
        
        <div className="container mx-auto px-4 relative z-10 text-center pt-20">
          <div className="flex items-center justify-center mb-6">
            <ChefHat className="h-16 w-16 text-primary" />
          </div>
          
          <h1 className="text-5xl md:text-7xl font-bold mb-6 text-foreground">
            Gastromania
          </h1>
          
          <p className="text-xl md:text-3xl mb-12 text-muted-foreground max-w-3xl mx-auto font-light">
            Mais do que comida, somos encontros que despertam memórias.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Link to="/dashboard">
              <Button size="xl" variant="hero">
                <Search className="h-5 w-5" />
                Encontrar Chefs
              </Button>
            </Link>
            <Link to="/auth?tab=signup">
              <Button size="xl" variant="accent">
                Cadastrar como Chef
              </Button>
            </Link>
          </div>
          
          <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className="text-center p-6 rounded-lg bg-card/50 backdrop-blur-sm border border-border">
              <Calendar className="h-12 w-12 mx-auto mb-4 text-primary" />
              <h3 className="font-semibold text-lg mb-2">Agende Facilmente</h3>
              <p className="text-sm text-muted-foreground">
                Veja a agenda em tempo real e reserve com um clique
              </p>
            </div>
            
            <div className="text-center p-6 rounded-lg bg-card/50 backdrop-blur-sm border border-border">
              <Star className="h-12 w-12 mx-auto mb-4 text-accent" />
              <h3 className="font-semibold text-lg mb-2">Chefs Verificados</h3>
              <p className="text-sm text-muted-foreground">
                Avaliações reais de clientes satisfeitos
              </p>
            </div>
            
            <div className="text-center p-6 rounded-lg bg-card/50 backdrop-blur-sm border border-border">
              <Shield className="h-12 w-12 mx-auto mb-4 text-secondary" />
              <h3 className="font-semibold text-lg mb-2">Pagamento Seguro</h3>
              <p className="text-sm text-muted-foreground">
                Múltiplas opções de pagamento protegidas
              </p>
            </div>
          </div>
        </div>
      </section>
      
      {/* Footer */}
      <footer className="bg-card border-t border-border py-8">
        <div className="container mx-auto px-4 text-center text-muted-foreground">
          <p>&copy; 2025 Gastromania. Todos os direitos reservados.</p>
        </div>
      </footer>
    </div>
  );
};

export default Landing;
