import { useState } from "react";
import { Navbar } from "@/components/Navbar";
import { ChefCard } from "@/components/ChefCard";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, SlidersHorizontal } from "lucide-react";
import chef1 from "@/assets/chef-1.jpg";
import chef2 from "@/assets/chef-2.jpg";
import chef3 from "@/assets/chef-3.jpg";

const mockChefs = [
  {
    id: "1",
    name: "Ricardo Silva",
    specialty: "Culinária Brasileira Contemporânea",
    image: chef1,
    rating: 4.9,
    reviewCount: 127,
    location: "São Paulo",
    available: true,
  },
  {
    id: "2",
    name: "Marina Costa",
    specialty: "Confeitaria & Doces Finos",
    image: chef2,
    rating: 4.8,
    reviewCount: 89,
    location: "Rio de Janeiro",
    available: false,
  },
  {
    id: "3",
    name: "Kenji Tanaka",
    specialty: "Culinária Japonesa Tradicional",
    image: chef3,
    rating: 5.0,
    reviewCount: 203,
    location: "São Paulo",
    available: true,
  },
  {
    id: "4",
    name: "Ricardo Silva",
    specialty: "Culinária Brasileira Contemporânea",
    image: chef1,
    rating: 4.7,
    reviewCount: 156,
    location: "Belo Horizonte",
    available: false,
  },
  {
    id: "5",
    name: "Marina Costa",
    specialty: "Confeitaria & Doces Finos",
    image: chef2,
    rating: 4.9,
    reviewCount: 92,
    location: "Curitiba",
    available: true,
  },
  {
    id: "6",
    name: "Kenji Tanaka",
    specialty: "Culinária Japonesa Tradicional",
    image: chef3,
    rating: 4.8,
    reviewCount: 178,
    location: "Porto Alegre",
    available: false,
  },
];

const Dashboard = () => {
  const [searchQuery, setSearchQuery] = useState("");

  const categories = [
    { name: "Mais bem avaliados", chefs: mockChefs.filter(c => c.rating >= 4.8) },
    { name: "Disponíveis hoje", chefs: mockChefs.filter(c => c.available) },
    { name: "Doces e Confeitaria", chefs: mockChefs.filter(c => c.specialty.includes("Confeitaria")) },
    { name: "Culinária Japonesa", chefs: mockChefs.filter(c => c.specialty.includes("Japonesa")) },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="container mx-auto px-4 pt-24 pb-12">
        {/* Search Bar */}
        <div className="mb-12">
          <h1 className="text-4xl font-bold mb-6 text-foreground">Encontre seu Chef</h1>
          <div className="flex gap-3 max-w-2xl">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              <Input
                placeholder="Buscar por especialidade, cidade ou nome do chef..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <Button variant="outline" size="icon">
              <SlidersHorizontal className="h-5 w-5" />
            </Button>
          </div>
        </div>

        {/* Categories */}
        <div className="space-y-12">
          {categories.map((category) => (
            <section key={category.name}>
              <h2 className="text-2xl font-semibold mb-6 text-foreground">
                {category.name}
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {category.chefs.map((chef) => (
                  <ChefCard key={`${category.name}-${chef.id}`} {...chef} />
                ))}
              </div>
            </section>
          ))}
        </div>
      </main>
    </div>
  );
};

export default Dashboard;
